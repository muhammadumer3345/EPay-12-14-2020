export class Employee {
  EmployeeID: number;
  FirstName: string;
  LastName: string;
  EmpCode: string;
  Position: string;
  Office: string;
}
